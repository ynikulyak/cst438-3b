package cst438;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cst4383ReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cst4383ReservationApplication.class, args);
	}

}
